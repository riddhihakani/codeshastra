const express = require('express');
const expressLayouts = require('express-ejs-layouts');
const mongoose = require('mongoose');
var bodyParser = require('body-parser')
const flash = require('connect-flash');
const session = require('express-session');
const passport = require('passport');

const app = express();
//passport config
require('./config/passport')(passport);


//connect to bodyparser
app.use(bodyParser.urlencoded({ extended: false }))

//express session
app.use(session({
    secret : 'secret',
    resave : true,
    saveUninitialized : true,
    cookie : {secure : true}
}));

//connect flash
app.use(flash());

//global vars
app.use((req,res,next) =>{
    res.locals.success_msg = req.flash('success_msg');
    res.locals.error_msg = req.flash('errror_msg');
    res.locals.error = req.flash('errror');
    next();
});

//connect to mongo
mongoose.connect('mongodb://localhost/db',{'useUnifiedTopology': true ,'useNewUrlParser': true})
  .then(() => console.log('MongoDB Connected ....'))
  .catch(err => console.log(err));
//mongoose.set('useNewUrlParser', true);


//ejs
app.use(expressLayouts);
app.set('view engine', 'ejs');



//routes
app.use('/',require('./routes/index'));
app.use('/users',require('./routes/users'));

const PORT = process.env.PORT || 5000;

app.listen(PORT,function(){
    console.log('server started on port 5000');
});
